
# Chess Site — Spring Boot (Auth + Puzzles + ELO + Battle)

**Run locally**
```bash
mvn spring-boot:run
# then open http://localhost:8080/index.html
```

**Build jar**
```bash
mvn clean package -DskipTests
java -jar target/chess-site-0.2.0.jar
```

**Deploy on Render.com**
- Web Service → Java 17
- Build Command: `mvn clean package -DskipTests`
- Start Command: `java -jar target/chess-site-0.2.0.jar`
- After deploy: open `/index.html` and `/puzzles.html`

**VPS quick run**
```bash
sudo apt update && sudo apt -y install openjdk-17-jdk maven
mvn clean package -DskipTests
nohup java -jar target/chess-site-0.2.0.jar &
```

H2 in-memory is enabled by default. For persistence, switch to PostgreSQL and set `spring.datasource.*` accordingly.
