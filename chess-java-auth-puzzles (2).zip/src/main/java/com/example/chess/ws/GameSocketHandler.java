
package com.example.chess.ws;

import com.example.chess.model.*;
import com.example.chess.service.*;
import com.example.chess.entity.*;
import com.example.chess.repo.*;
import com.github.bhlangonijr.chesslib.Board;
import com.github.bhlangonijr.chesslib.Square;
import com.github.bhlangonijr.chesslib.move.Move;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class GameSocketHandler extends TextWebSocketHandler {

    @Autowired private GameRoomManager rooms;
    @Autowired private EloService elo;
    @Autowired private UserRepo users;
    @Autowired private RatingRepo ratings;

    private final ObjectMapper om = new ObjectMapper();

    private final Map<String,String> sessionUser = new ConcurrentHashMap<>();
    private final Map<String,String> drawOffer = new ConcurrentHashMap<>();
    private final Map<String,Set<WebSocketSession>> roomSessions = new ConcurrentHashMap<>();

    private void joinRoomSession(String roomId, WebSocketSession s){
        roomSessions.computeIfAbsent(roomId, k -> new HashSet<>()).add(s);
    }
    private void broadcast(String roomId, Map<String,Object> payload) throws Exception {
        var msg = new TextMessage(om.writeValueAsString(payload));
        for (var s : roomSessions.getOrDefault(roomId, Set.of())) {
            if (s.isOpen()) s.sendMessage(msg);
        }
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) { }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        Map<String,Object> msg = om.readValue(message.getPayload(), Map.class);
        String op = (String) msg.get("op");

        if ("hello".equals(op)) {
            String username = (String) msg.get("username");
            sessionUser.put(session.getId(), username);
            session.sendMessage(new TextMessage("{"op":"hello","ok":true}"));
        }

        else if ("create".equals(op)) {
            String mode = (String) msg.getOrDefault("mode", "NORMAL");
            String variant = (String) msg.getOrDefault("variant", "STANDARD");
            int base = (int) msg.getOrDefault("base", 5);
            int inc = (int) msg.getOrDefault("inc", 0);
            int games = (int) msg.getOrDefault("games", 6);
            String me = sessionUser.get(session.getId());
            if (GameType.valueOf(mode)==GameType.BATTLE && games < 6) games = 6;
            GameRoom room = rooms.createRoom(GameType.valueOf(mode), Variant.valueOf(variant), new TimeControl(base, inc), games, me, null);
            joinRoomSession(room.getId(), session);
            session.sendMessage(new TextMessage("{"op":"created","roomId":""+room.getId()+"","fen":""+room.getBoard().getFen()+""}"));
        }

        else if ("join".equals(op)) {
            String roomId = (String) msg.get("roomId");
            GameRoom room = rooms.get(roomId);
            if (room == null) { session.sendMessage(new TextMessage("{"op":"error","msg":"Room not found"}")); return; }
            String me = sessionUser.get(session.getId());
            if (room.getBlackUser()==null && (room.getWhiteUser()==null || !me.equals(room.getWhiteUser()))) room.setBlackUser(me);
            else if (room.getWhiteUser()==null && (room.getBlackUser()==null || !me.equals(room.getBlackUser()))) room.setWhiteUser(me);
            joinRoomSession(roomId, session);
            broadcast(roomId, Map.of("op","ready","fen", room.getBoard().getFen(), "white", room.getWhiteUser(), "black", room.getBlackUser()));
            if (room.getWhiteUser()!=null && room.getBlackUser()!=null) {
                room.startClocks();
                broadcast(roomId, Map.of("op","start","fen", room.getBoard().getFen(), "wMs", room.getWhiteMs(), "bMs", room.getBlackMs(),
                        "tc", Map.of("base", room.getTc().baseMinutes, "inc", room.getTc().incrementSeconds), "variant", room.getVariant().name(),
                        "type", room.getType().name(), "games", room.getTotalGames()));
            }
        }

        else if ("move".equals(op)) {
            String roomId = (String) msg.get("roomId");
            String uci = (String) msg.get("uci");
            GameRoom room = rooms.get(roomId);
            if (room == null || !room.isLive()) return;
            String mover = "w".equals(room.currentTurn()) ? room.getWhiteUser() : room.getBlackUser();
            String me = sessionUser.get(session.getId());
            if (!Objects.equals(me, mover)) { session.sendMessage(new TextMessage("{"op":"error","msg":"Not your turn"}")); return; }

            room.applyElapsed();
            if (room.flagFell()) { finishGame(roomId, room, "time", room.getWhiteMs()<=0? "b":"w"); return; }

            try {
                String from = uci.substring(0,2);
                String to = uci.substring(2,4);
                Move mv = new Move(Square.fromValue(from.toUpperCase()), Square.fromValue(to.toUpperCase()));
                Board board = room.getBoard();
                if (!board.legalMoves().contains(mv)) { session.sendMessage(new TextMessage("{"op":"illegal"}")); return; }
                board.doMove(mv);
                room.addIncrementToMover();
                room.setTurnStartedAt(System.currentTimeMillis());
                broadcast(roomId, Map.of("op","moved","uci",uci,"fen",board.getFen(),"wMs",room.getWhiteMs(),"bMs",room.getBlackMs()));

                if (board.isMated()) {
                    String winner = mover.equals(room.getWhiteUser()) ? "w" : "b";
                    finishGame(roomId, room, "mate", winner);
                } else if (board.isStaleMate() || board.isDraw()) {
                    finishGame(roomId, room, "draw", null);
                }
            } catch (Exception e) {
                session.sendMessage(new TextMessage("{"op":"error","msg":"Bad move format"}"));
            }
        }

        else if ("offerDraw".equals(op)) {
            String roomId = (String) msg.get("roomId");
            drawOffer.put(roomId, sessionUser.get(session.getId()));
            broadcast(roomId, Map.of("op","drawOffered","by", drawOffer.get(roomId)));
        }

        else if ("acceptDraw".equals(op)) {
            String roomId = (String) msg.get("roomId");
            GameRoom room = rooms.get(roomId);
            if (room==null || !room.isLive()) return;
            finishGame(roomId, room, "draw-agreed", null);
        }

        else if ("resign".equals(op)) {
            String roomId = (String) msg.get("roomId");
            GameRoom room = rooms.get(roomId);
            if (room==null || !room.isLive()) return;
            String me = sessionUser.get(session.getId());
            String winner = me.equals(room.getWhiteUser()) ? "b" : "w";
            finishGame(roomId, room, "resign", winner);
        }
    }

    private void finishGame(String roomId, GameRoom room, String reason, String winner) throws Exception {
        room.setLive(false);
        String result = (winner==null) ? "1/2-1/2" : (winner.equals("w") ? "1-0" : "0-1");
        room.setLastResult(result);
        if ("1-0".equals(result)) room.setWhiteScore(room.getWhiteScore()+1);
        else if ("0-1".equals(result)) room.setBlackScore(room.getBlackScore()+1);

        broadcast(roomId, Map.of("op","gameover","reason",reason,"winner",winner,"score", Map.of("w",room.getWhiteScore(),"b",room.getBlackScore())));

        // ELO update per game
        String pool = room.getVariant().name() + ":" + room.getTc().tcClass();
        updateElo(pool, room.getWhiteUser(), room.getBlackUser(), result);

        if (room.getType()==GameType.BATTLE) {
            if (room.getCurrentGame() < room.getTotalGames()) {
                room.setCurrentGame(room.getCurrentGame()+1);
                room.resetBoardForVariant();
                room.startClocks();
                broadcast(roomId, Map.of("op","next","game",room.getCurrentGame(),"fen", room.getBoard().getFen(), "wMs", room.getWhiteMs(), "bMs", room.getBlackMs()));
            } else {
                if (room.getWhiteScore()==room.getBlackScore()) {
                    // Armageddon
                    room.setType(GameType.ARMAGEDDON);
                    room.resetBoardForVariant();
                    room.setWhiteMs(Math.round(room.getTc().baseMs() * 1.75));
                    room.setBlackMs(room.getTc().baseMs());
                    room.setTurnStartedAt(System.currentTimeMillis());
                    room.setLive(true);
                    broadcast(roomId, Map.of("op","armageddon","fen", room.getBoard().getFen(), "wMs", room.getWhiteMs(), "bMs", room.getBlackMs()));
                } else {
                    broadcast(roomId, Map.of("op","matchover","winner", room.getWhiteScore()>room.getBlackScore() ? "w" : "b"));
                }
            }
        }
    }

    private void updateElo(String pool, String white, String black, String result){
        User uw = users.findByUsername(white).orElseGet(() -> users.save(new User(null, white, "")));
        User ub = users.findByUsername(black).orElseGet(() -> users.save(new User(null, black, "")));
        Rating rw = ratings.findByUserAndPool(uw, pool).orElseGet(() -> ratings.save(new Rating(null, uw, pool, 1200)));
        Rating rb = ratings.findByUserAndPool(ub, pool).orElseGet(() -> ratings.save(new Rating(null, ub, pool, 1200)));
        double sa = switch (result){
            case "1-0" -> 1.0;
            case "0-1" -> 0.0;
            default -> 0.5;
        };
        int[] upd = elo.update(rw.getElo(), rb.getElo(), sa);
        rw.setElo(upd[0]); rb.setElo(upd[1]);
        ratings.save(rw); ratings.save(rb);
    }
}
