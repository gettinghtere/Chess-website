
package com.example.chess.service;

import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class MatchmakingService {
    private final Map<String, List<Entry>> queues = new ConcurrentHashMap<>();
    public static record Entry(String username, int elo){}

    public synchronized Optional<List<Entry>> enqueueAndTryMatch(String pool, Entry entry){
        queues.computeIfAbsent(pool, k -> new ArrayList<>()).add(entry);
        List<Entry> q = queues.get(pool);
        if (q.size() < 2) return Optional.empty();
        q.sort(Comparator.comparingInt(Entry::elo));
        int bestGap = Integer.MAX_VALUE; int iBest = -1;
        for (int i=0;i<q.size()-1;i++){
            int gap = Math.abs(q.get(i).elo() - q.get(i+1).elo());
            if (gap < bestGap){ bestGap=gap; iBest=i; }
        }
        Entry a = q.remove(iBest);
        Entry b = q.remove(iBest);
        return Optional.of(List.of(a,b));
    }

    public synchronized void removeFromQueue(String pool, String username){
        List<Entry> q = queues.get(pool);
        if (q==null) return;
        q.removeIf(e -> e.username().equals(username));
    }
}
