
package com.example.chess.service;

import org.springframework.stereotype.Service;

@Service
public class EloService {
    private static final int K = 32;
    public int[] update(int ra, int rb, double sa) {
        double ea = 1.0 / (1.0 + Math.pow(10, (rb - ra) / 400.0));
        double eb = 1.0 - ea;
        int na = (int)Math.round(ra + K * (sa - ea));
        int nb = (int)Math.round(rb + K * ((1.0 - sa) - eb));
        return new int[]{na, nb};
    }
}
