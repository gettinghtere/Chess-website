
package com.example.chess.service;

import com.example.chess.model.*;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class GameRoomManager {
    private final Map<String, GameRoom> rooms = new ConcurrentHashMap<>();

    public GameRoom createRoom(GameType type, Variant variant, TimeControl tc, int totalGames, String whiteUser, String blackUser) {
        GameRoom room = new GameRoom();
        room.setId(generateId());
        room.setType(type);
        room.setVariant(variant);
        room.setTc(tc);
        room.setTotalGames(Math.max(1, totalGames));
        room.setWhiteUser(whiteUser);
        room.setBlackUser(blackUser);
        room.resetBoardForVariant();
        rooms.put(room.getId(), room);
        return room;
    }

    private String generateId() {
        String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<6;i++) sb.append(alphabet.charAt(r.nextInt(alphabet.length())));
        return sb.toString();
    }

    public GameRoom get(String id) { return rooms.get(id); }
    public void remove(String id) { rooms.remove(id); }
}
