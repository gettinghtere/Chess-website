
package com.example.chess.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.chess.entity.Rating;
import com.example.chess.entity.User;
import java.util.Optional;

public interface RatingRepo extends JpaRepository<Rating, Long> {
    Optional<Rating> findByUserAndPool(User user, String pool);
}
