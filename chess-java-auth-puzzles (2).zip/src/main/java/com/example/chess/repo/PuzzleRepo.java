
package com.example.chess.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.chess.entity.Puzzle;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface PuzzleRepo extends JpaRepository<Puzzle, Long> {
    @Query("SELECT p FROM Puzzle p WHERE p.rating BETWEEN :min AND :max")
    List<Puzzle> findByRatingBetween(@Param("min") int min, @Param("max") int max);
}
