
package com.example.chess.model;

public class TimeControl {
    public int baseMinutes;
    public int incrementSeconds;
    public TimeControl(){}
    public TimeControl(int b, int i){ this.baseMinutes=b; this.incrementSeconds=i; }
    public long baseMs(){ return baseMinutes * 60_000L; }
    public long incMs(){ return incrementSeconds * 1000L; }
    public String tcClass(){
        int m = baseMinutes;
        if (m <= 2) return "bullet";
        if (m <= 5) return "blitz";
        if (m <= 15) return "rapid";
        return "classical";
    }
}
