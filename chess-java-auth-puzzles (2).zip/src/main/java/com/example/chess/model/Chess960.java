
package com.example.chess.model;

import java.util.*;

public class Chess960 {
    public static String randomStartFEN() {
        Random r = new Random();
        char[] back = new char[8];
        Arrays.fill(back, '.');
        int b1 = 2 * r.nextInt(4);
        int b2 = 1 + 2 * r.nextInt(4);
        back[b1] = 'B'; back[b2] = 'B';
        int q; do { q = r.nextInt(8); } while (back[q] != '.'); back[q] = 'Q';
        for (int k=0;k<2;k++){ int n; do { n=r.nextInt(8);} while(back[n]!='.'); back[n]='N'; }
        int[] e = new int[3]; int idx=0; for(int i=0;i<8;i++) if(back[i]=='.') e[idx++]=i;
        Arrays.sort(e);
        back[e[0]]='R'; back[e[1]]='K'; back[e[2]]='R';
        String br = new String(back).toLowerCase();
        String white = br; String black = br.toUpperCase();
        return black + "/pppppppp/8/8/8/8/PPPPPPPP/" + white + " w KQkq - 0 1";
    }
}
