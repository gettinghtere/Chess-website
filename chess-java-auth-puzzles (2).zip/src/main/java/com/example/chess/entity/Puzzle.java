
package com.example.chess.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name="puzzles")
@Data @NoArgsConstructor @AllArgsConstructor
public class Puzzle {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @Column(length=120, nullable=false)
    private String fen;

    @Column(length=1024, nullable=false)
    private String solutionSan; // space-separated SAN line
    
    private int rating; // 400–3000
    
    @Column(length=256)
    private String themes; // comma-separated tags
}
