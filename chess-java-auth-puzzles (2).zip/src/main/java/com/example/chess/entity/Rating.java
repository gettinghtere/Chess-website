
package com.example.chess.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name="ratings")
@Data @NoArgsConstructor @AllArgsConstructor
public class Rating {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional=false)
    private User user;

    @Column(nullable=false)
    private String pool; // e.g., STANDARD:blitz

    @Column(nullable=false)
    private int elo = 1200;
}
