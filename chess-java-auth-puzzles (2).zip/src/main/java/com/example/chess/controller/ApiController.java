
package com.example.chess.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import com.example.chess.entity.*;
import com.example.chess.repo.*;
import com.example.chess.service.MatchmakingService;

@RestController
@RequestMapping("/api")
public class ApiController {

    @Autowired private UserRepo users;
    @Autowired private RatingRepo ratings;
    @Autowired private MatchmakingService mm;

    record RatingResponse(String pool, int elo) {}
    @GetMapping("/rating/{username}/{variant}/{tcclass}")
    public RatingResponse rating(@PathVariable String username, @PathVariable String variant, @PathVariable String tcclass){
        User u = users.findByUsername(username).orElseThrow();
        String pool = variant + ":" + tcclass;
        Rating r = ratings.findByUserAndPool(u, pool).orElseGet(() -> ratings.save(new Rating(null, u, pool, 1200)));
        return new RatingResponse(pool, r.getElo());
    }

    record EnqueueReq(String username, String variant, String tcclass, int elo){}
    @PostMapping("/match/enqueue")
    public Map<String,Object> enqueue(@RequestBody EnqueueReq req){
        var res = mm.enqueueAndTryMatch(req.variant()+":"+req.tcclass(), new MatchmakingService.Entry(req.username(), req.elo()));
        return res.<Map<String,Object>>map(list -> Map.of("matched", true, "players", list))
                .orElseGet(() -> Map.of("matched", false));
    }

    @PostMapping("/match/cancel")
    public void cancel(@RequestBody EnqueueReq req){
        mm.removeFromQueue(req.variant()+":"+req.tcclass(), req.username());
    }
}
