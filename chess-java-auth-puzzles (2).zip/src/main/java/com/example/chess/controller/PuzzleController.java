
package com.example.chess.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.chess.entity.Puzzle;
import com.example.chess.repo.PuzzleRepo;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

@RestController
@RequestMapping("/api/puzzles")
public class PuzzleController {

    @Autowired private PuzzleRepo puzzles;

    record UpsertPuzzle(String fen, String solutionSan, int rating, String themes) {}

    @PostMapping("/import")
    public Map<String,Object> importBatch(@RequestBody List<UpsertPuzzle> batch){
        List<Puzzle> toSave = new ArrayList<>();
        for (var p : batch){
            toSave.add(new Puzzle(null, p.fen(), p.solutionSan(), p.rating(), p.themes()));
        }
        puzzles.saveAll(toSave);
        return Map.of("ok", true, "count", toSave.size());
    }

    @GetMapping("/random")
    public Puzzle random(@RequestParam(defaultValue="400") int min,
                         @RequestParam(defaultValue="2200") int max){
        List<Puzzle> list = puzzles.findByRatingBetween(min, max);
        if (list.isEmpty()) throw new RuntimeException("No puzzles in range");
        return list.get(ThreadLocalRandom.current().nextInt(list.size()));
    }
}
