
package com.example.chess.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.example.chess.entity.User;
import com.example.chess.repo.UserRepo;

import jakarta.servlet.http.HttpSession;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired private UserRepo users;
    @Autowired private PasswordEncoder encoder;

    record RegisterReq(String username, String password){}
    record LoginReq(String username, String password){}

    @PostMapping("/register")
    public Map<String,Object> register(@RequestBody RegisterReq req){
        if (users.findByUsername(req.username()).isPresent())
            return Map.of("ok", false, "error", "username_taken");
        User u = new User(null, req.username(), encoder.encode(req.password()));
        users.save(u);
        return Map.of("ok", true);
    }

    @PostMapping("/login")
    public Map<String,Object> login(@RequestBody LoginReq req, HttpSession session){
        var u = users.findByUsername(req.username()).orElse(null);
        if (u==null || !encoder.matches(req.password(), u.getPasswordHash()))
            return Map.of("ok", false, "error", "invalid_credentials");
        session.setAttribute("uid", u.getId());
        session.setAttribute("username", u.getUsername());
        return Map.of("ok", true, "username", u.getUsername());
    }

    @PostMapping("/logout")
    public Map<String,Object> logout(HttpSession session){
        session.invalidate();
        return Map.of("ok", true);
    }

    @GetMapping("/me")
    public Map<String,Object> me(HttpSession session){
        Object un = session.getAttribute("username");
        return Map.of("authenticated", un!=null, "username", un);
    }
}
